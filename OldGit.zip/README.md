# WindowsAutoRestoreRecoveryPartition
files needed to build my Windows AutoRestore Recovery Partition for end user devices
